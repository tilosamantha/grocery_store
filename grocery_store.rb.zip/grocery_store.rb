##### Objective #####
# See Store -> def: show_store
# Add Item -> def: add_item
# Remove Item -> def: remove_item

 #create grocery store = []
  #noodles
  #marinera sauce
  #parmasean
  #meatballs
  #salt
  #pepper
#customer cart = []
#user option menu
  #add item
  #remove item
  #show entire cart
  #show the cost of cart
  #add new items to store

@store = [
  {item: "noodles", price: 5.00},
  {item: "marinera sauce", price: 7.00},
  {item: "parmasean", price: 5.50},
  {item: "meatball", price: 10000.00},
  {item: "salt", price: 200.00},
  {item: "pepper", price: 201.00}
]

@cart = []

puts "Hello! Welcome to our Million Dollar Store!\n"

def menu
  seperator
  
  puts "What would you like to do?"
  puts "1) Add item to your cart"
  puts "2) Remove item from your cart"
  puts "3) See what's in your cart"
  puts "4) See the total price"
  puts "5) Add an item to the grocery store"
  puts "6) Exit"
end

def user_selection
  choice = gets.to_i
  case choice
  when 1
    see_store
    add_cart
    menu
  when 2
    remove_item
    menu
  when 3
    view_cart
    menu
  when 4
    cart_cost
    menu
  when 5
    add_store
    menu
  when 6
    puts "\nHave a good day!"
    exit
  else
    puts "Invalid Input. Try Again"
    menu
  end

  user_selection
end


def see_store 
  seperator
  puts "Here's whats available to purchase"
  @store.each_with_index do |food, index| 
    puts "#{index + 1} #{food[:item]} #{food[:price]}"
  end
end

def add_cart
  seperator
  puts "What would you like to add to your cart? (Please input number):"
  items = see_store
  choice = gets.to_i
  if choice > 0 && choice <= items.length
    item = items[choice - 1]
  else
    puts "Invalid input. Try again"
    add_cart
  end

  @cart << item
  puts @cart
end

def add_store
  seperator

  items = Hash.new()
  # puts "Enter the item you want to add to the store:"
  # items = [:item=>gets.chomp]
  # puts "Enter the price of the item: "
  # items = [:price=>gets.chomp]
  puts "Enter the item and price you want to add to the store: "  #overwrites the same hash, need to create a new one
  new_food = gets.split(" ")
  items[:item] = new_food.first
  items[:price] = new_food.last.to_f
  
  @store << items
  puts @store
end


def remove_item
  seperator

  puts "What would you like to remove? (Please input number):"
  view_cart
  choice = gets.to_i
  if choice > 0 && choice <= @cart.length
    item = @cart.delete_at(choice - 1)
    # item = items[choice - 1]
  else
    puts "Invalid input. Try again"
    remove_item
  end
  puts "This is what you have left in your cart"
  puts @cart
end

def view_cart
  seperator

  puts "Here's what you have in your cart right now: "
  @cart.each_with_index do |food, index| 
    puts "#{index + 1} #{food[:item]} $#{food[:price]}"
  end
end

def cart_cost
  seperator

  puts "This is the total cost of the items in your cart: "
  cost = 0
  @cart.each_with_index do |food, index|
    cost += food[:price]
  end  
  puts "$ #{cost}" + "0"
end

def seperator
  puts "*" * 10
  puts
end

menu
user_selection